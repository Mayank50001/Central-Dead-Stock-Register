default_app_config = 'inventory.apps.InventoryConfig'
